Outlawed the Mod - Release 1.0.1 by creature9/Nathan Doris

Overview
--------------------------------
'Outlawed' is a non-permanent modification to Outlaws. It provides additional statistics for multiplayer gameplay that you find in modern games (such as KDR). Also for those dynamite lovers out there... a 'height' feature that shows you exactly how high you fly. Also the ability to save your stats to a photo for upload / bragging rights (Make sure you hit the 'HOME' key prior to the game exiting to the credits screen to save your score)

REQUIREMENTS
--------------------------------
-GOG/CD/(my keyboard patched version). Will NOT work with Steam version unless olwin.exe is overwritten by a compatible version.
-"olcfg" must be set to 3Dfx Glide or Direct3D and the emulator MUST be NGLIDE. (Compatible emulators must use direct3d9 for this to work)

HOW TO INSTALL
--------------------------------
-Extract 'Outlawed' to your Outlaws directory and overwrite the original olhook.dll with this version

REMOVAL
--------------------------------
-Delete the 'Outlawed' directory
-Delete olhook.dll
-Rename oldhook.dll to olhook.dll and everything will work as pre-mod

KEYS
--------------------------------
-F11 - Toggles the characters height on/off
-F12 - Toggles the charactrs stats on/off
-HOME - saves your characters stats to C:\GOG Outlaws\Outlawed\Saves\ (Will trigger the WEAPON.WAV sound upon success)
